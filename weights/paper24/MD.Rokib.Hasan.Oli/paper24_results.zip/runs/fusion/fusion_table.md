Test plates: 651, val plates: 766. "vs chars_v8n": the val-best single model; fixed / broken = test plates the row gets right / wrong where chars_v8n does not, p = exact McNemar. ms: summed per plate; fallback = average (helpers only run on some plates).

| models | rule | val exact % | test exact % | test CER % | fixed / broken vs chars_v8n (p) | ms/plate |
|---|---|---|---|---|---|---|
| chars_v8n | single | 82.38 | 86.79 | 2.51 |  | 9.36 |
| slot | single | 47.65 | 57.6 | 11.42 |  | 1.15 |
| crnn | single | 62.27 | 73.43 | 5.53 |  | 6.47 |
| vitstr | single | 20.63 | 20.89 | 24.33 |  | 10.18 |
| chars_v8n + crnn + vitstr | fallback | 85.12 | 88.63 | 2.73 | 12 / 0 (p 0.0005) | 10.54 (helpers on 7.07 %) |
| chars_v8n + crnn | fallback | 84.99 | 88.63 | 2.69 | 12 / 0 (p 0.0005) | 9.82 (helpers on 7.07 %) |
| chars_v8n + crnn | MV-BM+format | 84.99 | 88.63 | 2.69 | 12 / 0 (p 0.0005) | 15.83 |
| chars_v8n + crnn + vitstr | MV-BM+format | 84.99 | 88.33 | 2.75 | 12 / 2 (p 0.0129) | 26.01 |
| chars_v8n + slot + crnn | fallback | 84.86 | 88.63 | 2.74 | 12 / 0 (p 0.0005) | 9.9 (helpers on 7.07 %) |
| chars_v8n + slot + crnn + vitstr | fallback | 84.86 | 88.48 | 2.78 | 11 / 0 (p 0.001) | 10.62 (helpers on 7.07 %) |
| chars_v8n + slot + crnn | MV-BM+format | 84.07 | 87.4 | 2.81 | 12 / 8 (p 0.5034) | 16.98 |
| chars_v8n + slot | fallback | 83.55 | 87.71 | 2.52 | 6 / 0 (p 0.0312) | 9.44 (helpers on 7.07 %) |
| chars_v8n + slot + vitstr | fallback | 83.55 | 87.71 | 3.02 | 6 / 0 (p 0.0312) | 10.16 (helpers on 7.07 %) |
| chars_v8n + slot | MV-BM+format | 83.55 | 87.71 | 2.52 | 6 / 0 (p 0.0312) | 10.51 |
| chars_v8n + slot + crnn + vitstr | MV-BM+format | 83.55 | 87.1 | 2.86 | 11 / 9 (p 0.8238) | 27.16 |
| chars_v8n + vitstr | fallback | 83.03 | 87.1 | 3.32 | 2 / 0 (p 0.5) | 10.08 (helpers on 7.07 %) |
| chars_v8n + vitstr | MV-BM+format | 83.03 | 87.1 | 3.32 | 2 / 0 (p 0.5) | 19.54 |
| chars_v8n + slot + vitstr | MV-BM+format | 82.9 | 87.4 | 3.04 | 6 / 2 (p 0.2891) | 20.69 |
| chars_v8n + slot + crnn | MV-BM | 82.64 | 86.33 | 2.52 | 5 / 8 (p 0.5811) | 16.98 |

- Best single on val: chars_v8n, test 86.79 %.
- Chosen on val (all rules): chars_v8n + crnn + vitstr, fallback: val 85.12 %, test 88.63 % (+1.84 pp vs chars_v8n; fixed 12, broken 0, exact McNemar p = 0.0005), 10.54 ms per plate (helpers run on 7.07 % of the test plates).
- Best of the paper's rules: chars_v8n + slot + crnn, MV-BM: val 82.64 %, test 86.33 % (-0.46 pp vs chars_v8n; fixed 5, broken 8, exact McNemar p = 0.5811), 16.98 ms per plate.
- Best fallback: chars_v8n + crnn + vitstr, fallback: val 85.12 %, test 88.63 % (+1.84 pp vs chars_v8n; fixed 12, broken 0, exact McNemar p = 0.0005), 10.54 ms per plate (helpers run on 7.07 % of the test plates).
- Oracle (any model right): test 90.02 %.
