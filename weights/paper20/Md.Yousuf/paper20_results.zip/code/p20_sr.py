"""Paper #20 on Bangla plates: super-resolution in front of the OCR, and voting over several low-res copies.

  python p20_sr.py train --name sr_x2 --project runs --epochs 60          # PLNET-style x2 SR on our train crops
  python p20_sr.py eval  --sr runs/sr_x2/sr.pt --ocr runs/crnn_hr/model_full.pt --name sr_eval --project runs

No real LR/HR pairs exist for our plates, so LR copies are made from HR crops (>= 40 px high): bicubic/area down x2,
Gaussian blur, noise, JPEG (the paper warns this overstates SR gains, p.8). Plates are handled at HR 64x128, LR 32x64.
eval: OCR (any seq.py model, trained on HR crops) on HR | LR | bicubic x2 | our SR | Real-ESRGAN x4plus (zero-shot,
      resized to HR) for the test plates; then 5 differently degraded LR copies per plate -> SR -> OCR -> fused with
      HC, MV-HC and per-token MVCP-HC (metrics.fuse). Scores: plate exact, "all but one token right", CER, SR ms/plate.
"""
import argparse
import os
import random
import sys
import time
import urllib.request
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common
import metrics
import seq

HR = (128, 64)                        # (w, h)
ESRGAN = 'https://github.com/xinntao/Real-ESRGAN/releases/download/v0.1.0/RealESRGAN_x4plus.pth'


def hr_rows(split, min_h=40):
    rows = []
    for r in seq.load_rows(split):
        img = cv2.imread(r['path'])
        if img is not None and img.shape[0] >= min_h:
            rows.append(dict(r, img=cv2.resize(img, HR, interpolation=cv2.INTER_AREA)))
    return rows


def degrade(hr, rng, scale=2):
    img = hr.copy()
    s = rng.uniform(0.4, 1.4)
    img = cv2.GaussianBlur(img, (0, 0), s)
    interp = [cv2.INTER_AREA, cv2.INTER_CUBIC, cv2.INTER_LINEAR][rng.integers(3)]
    img = cv2.resize(img, (HR[0] // scale, HR[1] // scale), interpolation=interp)
    img = np.clip(img + rng.normal(0, rng.uniform(0, 8), img.shape), 0, 255).astype(np.uint8)
    ok, buf = cv2.imencode('.jpg', img, [cv2.IMWRITE_JPEG_QUALITY, int(rng.integers(30, 91))])
    return cv2.imdecode(buf, cv2.IMREAD_COLOR)


def to_t(img):
    return torch.from_numpy(img[:, :, ::-1].copy()).permute(2, 0, 1).float().div(255)


def to_img(t):
    return (t.clamp(0, 1).mul(255).byte().permute(1, 2, 0).cpu().numpy()[:, :, ::-1]).copy()


# ------------------------------------------------------------------ our SR (PLNET-like, x2)
class RCAB(nn.Module):
    def __init__(self, c, r=16):
        super().__init__()
        self.b = nn.Sequential(nn.Conv2d(c, c, 3, 1, 1), nn.ReLU(True), nn.Conv2d(c, c, 3, 1, 1))
        self.ca = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Conv2d(c, c // r, 1), nn.ReLU(True), nn.Conv2d(c // r, c, 1),
                                nn.Sigmoid())

    def forward(self, x):
        y = self.b(x)
        return x + y * self.ca(y)


class SRNet(nn.Module):
    def __init__(self, scale=2, c=64, n=10):
        super().__init__()
        self.scale = scale
        self.head = nn.Conv2d(3, c, 3, 1, 1)
        self.body = nn.Sequential(*[RCAB(c) for _ in range(n)], nn.Conv2d(c, c, 3, 1, 1))
        self.up = nn.Sequential(nn.Conv2d(c, 3 * scale * scale, 3, 1, 1), nn.PixelShuffle(scale))

    def forward(self, x):
        f = self.head(x)
        return self.up(f + self.body(f)) + F.interpolate(x, scale_factor=self.scale, mode='bicubic', align_corners=False)


# ------------------------------------------------------------------ Real-ESRGAN x4plus (RRDBNet, BasicSR layout)
class RDB(nn.Module):
    def __init__(self, nf=64, gc=32):
        super().__init__()
        self.conv1 = nn.Conv2d(nf, gc, 3, 1, 1)
        self.conv2 = nn.Conv2d(nf + gc, gc, 3, 1, 1)
        self.conv3 = nn.Conv2d(nf + 2 * gc, gc, 3, 1, 1)
        self.conv4 = nn.Conv2d(nf + 3 * gc, gc, 3, 1, 1)
        self.conv5 = nn.Conv2d(nf + 4 * gc, nf, 3, 1, 1)
        self.lrelu = nn.LeakyReLU(0.2, True)

    def forward(self, x):
        x1 = self.lrelu(self.conv1(x))
        x2 = self.lrelu(self.conv2(torch.cat((x, x1), 1)))
        x3 = self.lrelu(self.conv3(torch.cat((x, x1, x2), 1)))
        x4 = self.lrelu(self.conv4(torch.cat((x, x1, x2, x3), 1)))
        return self.conv5(torch.cat((x, x1, x2, x3, x4), 1)) * 0.2 + x


class RRDB(nn.Module):
    def __init__(self, nf=64, gc=32):
        super().__init__()
        self.rdb1, self.rdb2, self.rdb3 = RDB(nf, gc), RDB(nf, gc), RDB(nf, gc)

    def forward(self, x):
        return self.rdb3(self.rdb2(self.rdb1(x))) * 0.2 + x


class RRDBNet(nn.Module):
    def __init__(self, nf=64, nb=23, gc=32):
        super().__init__()
        self.conv_first = nn.Conv2d(3, nf, 3, 1, 1)
        self.body = nn.Sequential(*[RRDB(nf, gc) for _ in range(nb)])
        self.conv_body = nn.Conv2d(nf, nf, 3, 1, 1)
        self.conv_up1 = nn.Conv2d(nf, nf, 3, 1, 1)
        self.conv_up2 = nn.Conv2d(nf, nf, 3, 1, 1)
        self.conv_hr = nn.Conv2d(nf, nf, 3, 1, 1)
        self.conv_last = nn.Conv2d(nf, 3, 3, 1, 1)
        self.lrelu = nn.LeakyReLU(0.2, True)

    def forward(self, x):
        f = self.conv_first(x)
        f = f + self.conv_body(self.body(f))
        f = self.lrelu(self.conv_up1(F.interpolate(f, scale_factor=2, mode='nearest')))
        f = self.lrelu(self.conv_up2(F.interpolate(f, scale_factor=2, mode='nearest')))
        return self.conv_last(self.lrelu(self.conv_hr(f)))


def realesrgan(dev):
    path = Path(common.WORK) / 'RealESRGAN_x4plus.pth'
    if not path.exists():
        urllib.request.urlretrieve(ESRGAN, path)
    m = RRDBNet()
    sd = torch.load(path, map_location='cpu', weights_only=True)
    m.load_state_dict(sd.get('params_ema', sd.get('params', sd)))
    return m.eval().to(dev)


# ------------------------------------------------------------------ train
def train(a):
    dev = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    tr, va = hr_rows('train'), hr_rows('val')[:300]
    print('HR train crops', len(tr), 'val', len(va), flush=True)
    rng = np.random.default_rng(a.seed)
    vpairs = [(to_t(degrade(r['img'], np.random.default_rng(i), a.scale)), to_t(r['img'])) for i, r in enumerate(va)]
    model = SRNet(a.scale).to(dev)
    opt = torch.optim.Adam(model.parameters(), lr=2e-4)
    steps = a.epochs * max(1, len(tr) // a.batch)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, steps)
    t0, best = time.time(), 0
    for ep in range(a.epochs):
        model.train()
        random.shuffle(tr)
        for k in range(0, len(tr) - a.batch + 1, a.batch):
            batch = tr[k:k + a.batch]
            hr = torch.stack([to_t(r['img']) for r in batch]).to(dev)
            lr = torch.stack([to_t(degrade(r['img'], rng, a.scale)) for r in batch]).to(dev)
            loss = F.l1_loss(model(lr), hr)
            opt.zero_grad(); loss.backward(); opt.step(); sched.step()
        model.eval()
        with torch.no_grad():
            lr = torch.stack([p[0] for p in vpairs]).to(dev); hr = torch.stack([p[1] for p in vpairs]).to(dev)
            sr = torch.cat([model(lr[i:i + 64]) for i in range(0, len(lr), 64)]).clamp(0, 1)
            psnr = float((10 * torch.log10(1 / F.mse_loss(sr, hr, reduction='none').mean((1, 2, 3)))).mean())
            bic = F.interpolate(lr, scale_factor=a.scale, mode='bicubic', align_corners=False).clamp(0, 1)
            pb = float((10 * torch.log10(1 / F.mse_loss(bic, hr, reduction='none').mean((1, 2, 3)))).mean())
        print(f'epoch {ep + 1}: val PSNR SR {psnr:.2f} dB | bicubic {pb:.2f} dB', flush=True)
        if psnr > best:
            best = psnr
            torch.save({'state_dict': model.state_dict(), 'scale': a.scale}, Path(a.project) / a.name / 'sr.pt')
    return {'train_minutes': round((time.time() - t0) / 60, 1), 'val_psnr_sr_dB': round(best, 2),
            'val_psnr_bicubic_dB': round(pb, 2), 'train_crops': len(tr), 'scale': a.scale,
            'params_M': round(sum(p.numel() for p in model.parameters()) / 1e6, 3)}


# ------------------------------------------------------------------ eval
def load_ocr(path, dev):
    c = torch.load(path, map_location='cpu', weights_only=False)
    n = len(c['classes'])
    m = {'crnn': lambda: seq.CRNN(n, c['H']), 'slot': lambda: seq.SlotCNN(n),
         'vitstr': lambda: seq.ViTSTR(n, c['H'], c['W'])}[c['kind']]()
    m.load_state_dict(c['state_dict'])
    return m.eval().to(dev), c


@torch.no_grad()
def read(ocr, c, imgs, dev):
    x = torch.stack([seq.prep(i, c['H'], c['W'], c['stack'], False) for i in imgs]).to(dev)
    out = torch.cat([ocr(x[k:k + 128]).float() for k in range(0, len(x), 128)])
    toks, conf = seq.ctc_decode(out) if c['kind'] == 'crnn' else seq.fixed_decode(out)
    return [seq.vocab.tokens_to_text([c['classes'][k - 1] for k in t]) for t in toks], conf


def score(pred, truth):
    s = metrics.score_rows(zip(pred, truth))
    s['all_but_one_token_%'] = round(100 * float(np.mean([metrics.lev(metrics.tokens(p), metrics.tokens(t)) <= 1
                                                          for p, t in zip(pred, truth)])), 2)
    return s


@torch.no_grad()
def evaluate(a):
    dev = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    te = hr_rows('test')[:a.max_test]
    truth = [r['text'] for r in te]
    ocr, c = load_ocr(a.ocr, dev)
    sr = SRNet(a.scale).to(dev).eval()
    if a.sr:
        sr.load_state_dict(torch.load(a.sr, map_location=dev, weights_only=False)['state_dict'])
    esr = realesrgan(dev) if not a.no_esrgan else None

    def run_sr(model, lrs, up):
        outs, ms = [], []
        for i, lr in enumerate(lrs):
            x = to_t(lr)[None].to(dev)
            if dev.type == 'cuda': torch.cuda.synchronize()
            t = time.perf_counter()
            with torch.autocast('cuda', enabled=dev.type == 'cuda'):
                y = model(x).float()
            if dev.type == 'cuda': torch.cuda.synchronize()
            if i >= 5: ms.append(1000 * (time.perf_counter() - t))
            outs.append(cv2.resize(to_img(y[0]), HR, interpolation=cv2.INTER_AREA) if up != a.scale else to_img(y[0]))
        return outs, round(float(np.mean(ms)), 2) if ms else None

    res = {'test_plates': len(te), 'scale': a.scale, 'variants': {}, 'fusion_5_copies': {}}
    lr1 = [degrade(r['img'], np.random.default_rng(10_000 + i), a.scale) for i, r in enumerate(te)]
    variants = {'HR': [r['img'] for r in te], 'LR': lr1,
                'bicubic': [cv2.resize(l, HR, interpolation=cv2.INTER_CUBIC) for l in lr1]}
    ms = {}
    if a.sr:
        variants['SR_ours'], ms['SR_ours'] = run_sr(sr, lr1, a.scale)
    if esr is not None:
        variants['RealESRGAN_x4'], ms['RealESRGAN_x4'] = run_sr(esr, lr1, 4)
    for k, imgs in variants.items():
        pred, _ = read(ocr, c, imgs, dev)
        res['variants'][k] = dict(score(pred, truth), sr_ms_per_plate=ms.get(k))
        print(k, res['variants'][k], flush=True)
    # 5 degraded copies per plate -> (SR) -> OCR -> fusion
    copies = {k: [] for k in ['LR', 'bicubic'] + (['SR_ours'] if a.sr else [])}
    for j in range(5):
        lrs = [degrade(r['img'], np.random.default_rng(1000 * j + i), a.scale) for i, r in enumerate(te)]
        ins = {'LR': lrs, 'bicubic': [cv2.resize(l, HR, interpolation=cv2.INTER_CUBIC) for l in lrs]}
        if a.sr:
            ins['SR_ours'] = run_sr(sr, lrs, a.scale)[0]
        for k in copies:
            copies[k].append(read(ocr, c, ins[k], dev))
    for k, reads in copies.items():
        res['fusion_5_copies'][k] = {'single_copy': score(reads[0][0], truth)}
        for how in ('HC', 'MV-HC', 'MVCP-HC'):
            fused = [metrics.fuse([(f'c{j}', reads[j][0][i], reads[j][1][i]) for j in range(5)], how)
                     for i in range(len(te))]
            res['fusion_5_copies'][k][how] = score(fused, truth)
        print('fusion', k, res['fusion_5_copies'][k], flush=True)
    res['ocr_model'] = {'kind': c['kind'], 'file': a.ocr}
    return res


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('mode', choices=['train', 'eval'])
    p.add_argument('--name', required=True)
    p.add_argument('--project', required=True)
    p.add_argument('--scale', type=int, default=2)
    p.add_argument('--epochs', type=int, default=60)
    p.add_argument('--batch', type=int, default=32)
    p.add_argument('--sr', default='')
    p.add_argument('--ocr', default='')
    p.add_argument('--no-esrgan', action='store_true')
    p.add_argument('--max-test', type=int, default=None)
    p.add_argument('--seed', type=int, default=42)
    a = p.parse_args()
    random.seed(a.seed); np.random.seed(a.seed); torch.manual_seed(a.seed)
    (Path(a.project) / a.name).mkdir(parents=True, exist_ok=True)
    r = train(a) if a.mode == 'train' else evaluate(a)
    r.update({'run': a.name, 'kind': 'sr-' + a.mode, 'env': common.env_info()})
    common.save_json(r, Path(a.project) / a.name / 'results.json')
    print('DONE', a.name)
