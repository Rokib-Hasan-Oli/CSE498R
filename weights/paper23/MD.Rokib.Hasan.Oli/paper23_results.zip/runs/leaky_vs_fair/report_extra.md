
## Seen / unseen check (plate readers)

The two KUET versions split the crops differently, so a reader scored on the other version's test has trained on some of those crops. Groups per reader: A = the identical crop is in its train, B = the same plate text is in its train (another crop), C = unseen. Plate exact % of both readers on each group; only the rows "unseen by both" compare the two readers fairly.

| Test set | Groups by the train of | Group | Plates | rec_leaky (%) | rec_fair (%) | leaky - fair (pp) |
|---|---|---|---|---|---|---|
| leaky_test_all | rec_leaky | A: identical crop in train | 0 | – | – | – |
| leaky_test_all | rec_leaky | B: same plate text in train | 114 | 90.35 | 79.82 | +10.53 |
| leaky_test_all | rec_leaky | C: unseen | 80 | 78.75 | 75.0 | +3.75 |
| leaky_test_all | rec_fair | A: identical crop in train | 0 | – | – | – |
| leaky_test_all | rec_fair | B: same plate text in train | 0 | – | – | – |
| leaky_test_all | rec_fair | C: unseen | 194 | 85.57 | 77.84 | +7.73 |
| leaky_test_all | both | **unseen by both** | 80 | 78.75 | 75.0 | +3.75 |
| fair_test | rec_leaky | A: identical crop in train | 0 | – | – | – |
| fair_test | rec_leaky | B: same plate text in train | 114 | 90.35 | 79.82 | +10.53 |
| fair_test | rec_leaky | C: unseen | 80 | 78.75 | 75.0 | +3.75 |
| fair_test | rec_fair | A: identical crop in train | 0 | – | – | – |
| fair_test | rec_fair | B: same plate text in train | 0 | – | – | – |
| fair_test | rec_fair | C: unseen | 194 | 85.57 | 77.84 | +7.73 |
| fair_test | both | **unseen by both** | 80 | 78.75 | 75.0 | +3.75 |

## Scores that include training data

- det_leaky on leaky_test_all: 11 identical photos of 553 are in its train (its own published split: the near-duplicates the paper is about)
- det_leaky on fair_test: 20 identical photos of 540 are in its train -> cross-score contaminated, use `unseen`
- rec_leaky on leaky_test_all: 0 identical crops + 114 with the same plate text of 194 are in its train (its own published split: the near-duplicates the paper is about)
- rec_leaky on fair_test: 0 identical crops + 114 with the same plate text of 194 are in its train -> cross-score contaminated, use `unseen`

Cross-scores again on the items the model never trained on (identical photo / crop and, for readers, the same plate text left out):

| Model | Test set | Images | mAP50 (%) | mAP50-95 (%) | plate exact (%) | on the whole set |
|---|---|---|---|---|---|---|
| det_leaky | fair_test | 520 | 99.4 | 76.78 | – | 77.45 (mAP50-95_%) |
| rec_leaky | fair_test | 80 | 92.83 | 71.9 | 78.75 | 85.57 (plate_exact_%) |

## Training length

| Run | train images | epochs run | batch | optimiser steps (about) |
|---|---|---|---|---|
| det_leaky | 5620 | 50 | 16 | 17600 |
| det_fair | 1758 | 160 | 16 | 17600 |
| rec_leaky | 3391 | 80 | 32 | 8480 |
| rec_fair | 660 | 377 | 32 | 7917 |

## Plate readers by condition, without the KUET crops (plate exact %)

Both readers trained on KUET only; with the KUET crops left out (rec_leaky trained on many of them) the rest of the 498R OCR test is a cross-dataset test for both.

| Run | all test | clear | night | blurry | fog (real fog copies) | rain (synthetic) |
|---|---|---|---|---|---|---|
| rec_leaky (no KUET, 468 plates) | 50.21 | 48.15 | 50.85 | 74.19 | 23.08 | 47.44 |
| rec_fair (no KUET, 468 plates) | 50.0 | 47.35 | 59.32 | 64.52 | 26.92 | 42.52 |
